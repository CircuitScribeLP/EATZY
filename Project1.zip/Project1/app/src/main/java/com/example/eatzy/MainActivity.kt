package com.example.eatzy

import android.content.Intent
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val goToSignup = findViewById<Button>(R.id.signup)
        val goToLogin = findViewById<Button>(R.id.login)

        goToSignup.setOnClickListener {
            val intent = Intent(this, Signup::class.java)
            startActivity(intent)
        }

        goToLogin.setOnClickListener {
            val intent1 = Intent(this,  Login::class.java)
            startActivity(intent1)
        }
    }
}